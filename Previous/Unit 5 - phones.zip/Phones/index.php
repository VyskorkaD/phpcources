<html>
<head>
    <title>Товари</title>
    <meta charset="UTF-8">
    <style>
        .sku {
            color: grey;
        }
        .product {
            border: dotted 1px gray;
            margin:20px;
            padding: 20px;
        }
        .price {
            color: red;
            font-size: 22px;
        }
    </style>
</head>
<body>
<?php
include "data.php";
include "render.php";
?>
</body>
</html>

  