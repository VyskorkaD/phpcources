<?php

    $products = array(
        array(
            'id' => 1,
            'sku' => 't00001',
            'name' => 'Телефон 1',
            'price' => 3050,
            'qty' => 7,
            'discount' => 10,
        ),
        array(
            'id' => 2,
            'sku' => 't00002',
            'name' => 'Телефон 2',
            'price' => 5580,
            'qty' => 4,
            'discount' => 80,
        ),
        array(
            'id' => 3,
            'sku' => 't00003',
            'name' => 'Телефон 3',
            'price' => 8999,
            'qty' => 3,
            'discount' => 10,
        ),
        array(
            'id' => 4,
            'sku' => 't00004',
            'name' => 'Телефон 4',
            'price' => 4800,
            'qty' => 5,
            'discount' => 10,
        ),
        array(
            'id' => 5,
            'sku' => 't00005',
            'name' => 'Телефон 5',
            'price' => 5099,
            'qty' => 6,
            'discount' => 10,
        ),
    );

    $tmp = array(
            'id' => 0,
            'sku' => '',
            'name' => '',
            'price' => 0,
            'qty' => 0,
        );


?>
